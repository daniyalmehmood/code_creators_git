public class SumDouble {
    public int sumDouble(int a, int b) {
        int sum = a + b;
        if (a == b){sum = sum * 2;
        }
        return sum;
    }
}
