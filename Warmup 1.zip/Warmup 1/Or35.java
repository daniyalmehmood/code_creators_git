public class Or35 {
    public boolean or35(int n) {
        return(n % 3 == 0) || (n % 5 == 0);
    }
}
