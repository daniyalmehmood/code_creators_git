public class lastdigit {
    public boolean lastDigit(int a, int b) {
        return(a % 10 == b % 10);
    }
}
