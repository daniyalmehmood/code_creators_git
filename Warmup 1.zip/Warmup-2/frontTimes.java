public class frontTimes {
    public class Main { // Defines the class named Main
        public static String frontTimes(String str, int n) {
            int frontLen = Math.min(3, str.length());

            String front = str.substring(0, frontLen);
            StringBuilder result = new StringBuilder();

            for (int i = 0; i < n; i++) {
                result.append(front); // Append the front substring to the result
            }

            return result.toString();
        }

        public static void main(String[] args) { // Program entry point
            System.out.println(frontTimes("Chocolate", 2));
            // Test the method with "Ab" and repeat 4 times
            System.out.println(frontTimes("Ab", 4));
        }
    }
}
