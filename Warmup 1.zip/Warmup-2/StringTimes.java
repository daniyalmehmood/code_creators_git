public class StringTimes {
    public String StringTimes(String str, int n) {
        String result = "";
        for (int i=0; i<n; i++) {
            result = result + str;
        }
        return result;
    }

}
